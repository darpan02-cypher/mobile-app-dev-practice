package edu.uncc.assessment04.models;

import java.io.Serializable;

public class User implements Serializable {
    String email;
    String passcode;

    public User() {
    }

    public User(String email, String passcode) {
        this.email = email;
        this.passcode = passcode;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPasscode() {
        return passcode;
    }

    public void setPasscode(String passcode) {
        this.passcode = passcode;
    }

    @Override
    public String toString() {
        return email;
    }
}
