package edu.uncc.assessment04.models;

import java.io.Serializable;

public class GiftList implements Serializable {
    String name;

    public GiftList() {
    }

    public GiftList(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
